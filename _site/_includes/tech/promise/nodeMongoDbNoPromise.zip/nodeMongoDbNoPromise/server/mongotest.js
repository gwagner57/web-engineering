var MongoClient = require('mongodb').MongoClient;

function login(username, password, successCallback, errCallback) {
  MongoClient.connect("mongodb://localhost:27017/myapp", function(err, db) {
    var usersCollection = null, stream = null;
    if (err) errCallback(err);
    else {
      console.log("Connected to database");
      usersCollection = db.collection('users');
      stream = usersCollection.findOne(
        {username: username, password: password},
        function(err, user) {
          if (err) errCallback(err);
          else if (!user) errCallback();
          else successCallback(user);
        }
      );
    }
  });
};

login("johnny", "12345", 
  function (user) {
    console.log("Login successful");
    // now provide user access to the site...
  },
  function (err) {
    console.log("Login failed.");
    // user should be informed that the login failed...
  }
); 