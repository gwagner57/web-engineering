var port = 3000,
    http = require('http'), 
    httpServer = null;
    
// create HTTP server
httpServer = http.createServer(function (req, resp){
  resp.end(JSON.stringify(
    {timestamp: (new Date()).getTime(), 
     message: "Hi, I am the NodeJS HTTP server!"}));
});  
    
// start HTTP server
httpServer.listen(port, function(){
    //Callback triggered when server is successfully listening. Hurray!
    console.log("HTTP Server started on port " + port);
});