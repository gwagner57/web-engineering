package pl.model;

/**
 * Enumeration of book categories.
 *
 */
public enum BookCategoryEL {
  NOVEL, 
  BIOGRAPHY, 
  TEXTBOOK, 
  OTHER;
}