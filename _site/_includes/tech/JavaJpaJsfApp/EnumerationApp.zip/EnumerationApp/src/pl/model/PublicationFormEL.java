package pl.model;

/**
 * Enumeration of available publication forms.
 *
 */
public enum PublicationFormEL {
  HARDCOVER, 
  PAPERBACK, 
  EPUB, 
  PDF;
}