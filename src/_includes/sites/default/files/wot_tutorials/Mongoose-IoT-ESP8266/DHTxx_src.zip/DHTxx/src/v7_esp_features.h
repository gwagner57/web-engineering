// NOTE: add the following line to fw/platforms/esp8266/user/v7_esp_features.h file, as part of directive 
//       #ifndef CS_FW_PLATFORMS_ESP8266_USER_V7_ESP_FEATURES_H_ 
//       ... 
//       #endif 
#define V7_ESP_ENABLE__DHT
