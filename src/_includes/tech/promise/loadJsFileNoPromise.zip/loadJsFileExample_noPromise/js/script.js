function loadJsFile( filePath, onLoadFinishedCallback, onLoadErrorCallback) {
  var scriptElem = document.createElement('script');
  scriptElem.onload = onLoadFinishedCallback;
  scriptElem.onerror = onLoadErrorCallback;
  // trigger the file loading
  scriptElem.src = filePath;
  // append element to head
  document.head.appendChild(scriptElem );
};