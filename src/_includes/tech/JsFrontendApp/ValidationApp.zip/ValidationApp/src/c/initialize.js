/**
 * @fileOverview  Defining the main namespace ("public library") and its MVC subnamespaces
 * @author Gerd Wagner
 */
// main namespace pl = "public library"
var pl = { m:{}, v:{}, c:{} };
