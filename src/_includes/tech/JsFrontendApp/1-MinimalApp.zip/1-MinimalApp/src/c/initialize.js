/**
 * @fileOverview  Defining the main namespace ("public library") and its MVC subnamespaces
 * @author Gerd Wagner
 */
'use strict';
// main namespace pl = "public library"
var pl = { m:{}, v:{}, c:{} };
