/**
 * @fileOverview  Contains various controller functions for managing employees
 * @author Gerd Wagner
 */
pl.c.employees.manage = {
  initialize: function () {
    Person.retrieveAll();
    pl.v.employees.manage.setupUserInterface();
  }
};