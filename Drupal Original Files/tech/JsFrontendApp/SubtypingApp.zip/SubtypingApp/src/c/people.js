/**
 * @fileOverview  Contains various controller functions for managing books
 * @author Gerd Wagner
 */
pl.c.people.manage = {
  initialize: function () {
    Person.retrieveAll();
    pl.v.people.manage.setupUserInterface();
  }
};