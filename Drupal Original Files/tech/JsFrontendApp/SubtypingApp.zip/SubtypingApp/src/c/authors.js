/**
 * @fileOverview  Contains various controller functions for managing books
 * @author Gerd Wagner
 */
pl.c.authors.manage = {
  initialize: function () {
    Person.retrieveAll();
    pl.v.authors.manage.setupUserInterface();
  }
};