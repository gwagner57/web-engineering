var MongoClient = require('mongodb').MongoClient;

function login(username, password) {
  return new Promise(function (resolve, reject) {
    MongoClient.connect("mongodb://localhost:27017/myapp", function(err, db) {
      var usersCollection = null, stream = null;
      if (err) reject(err);
      else {
        usersCollection = db.collection('users');
        stream = usersCollection.findOne(
          {username: username, password: password},
          function(err, user) {
            if (err) reject(err);
            else if (!user) reject();
            else resolve(user);
          }
        );
      }
    });
  });
}; 

login("johnny", "12345")
.then(function (user) {
    console.log("Login successful");
    // now provide user access to the site...
})
.catch(function (err) {
    console.log("Login failed.");
    // user should be informed that the login failed...
}); 